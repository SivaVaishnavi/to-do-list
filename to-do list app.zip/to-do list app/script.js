const inputbox=document.getElementById("input-box")
const ul=document.getElementById("ul-container")
function addTask(){
    if(inputbox.value===""){
        alert("You must enter something")   
    }
    else{
        let li=document.createElement("li");
        li.innerHTML=inputbox.value
        ul.appendChild(li)
        let span=document.createElement("span")
        span.innerHTML="\u00d7"
        li.appendChild(span)
    }
    inputbox.value="";
    saveData();
}
ul.addEventListener("click",function(e){
    if(e.target.tagName==="LI"){
        e.target.classList.toggle("checked")
        saveData();
    }   
    else if(e.target.tagName==="SPAN"){
        e.target.parentElement.remove();
        saveData();
    }
})
function saveData(){
    localStorage.setItem("data",ul.innerHTML)
}
function showTask(){
    ul.innerHTML=localStorage.getItem("data")
}
showTask()